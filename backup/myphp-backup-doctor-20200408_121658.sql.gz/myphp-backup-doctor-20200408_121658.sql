CREATE DATABASE IF NOT EXISTS `doctor`;

USE `doctor`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `castomer`;

CREATE TABLE `castomer` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `Patientid` varchar(50) COLLATE utf8mb4_persian_ci NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_persian_ci NOT NULL,
  `surname` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `age` int(5) NOT NULL,
  `gender` varchar(10) COLLATE utf8mb4_persian_ci NOT NULL,
  `Province` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `Job` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `Diagnosis1` varchar(111) COLLATE utf8mb4_persian_ci NOT NULL,
  `Diagnosis2` varchar(111) COLLATE utf8mb4_persian_ci NOT NULL,
  `Diagnosis3` varchar(111) COLLATE utf8mb4_persian_ci NOT NULL,
  `BP` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `HR` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `PR` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `RR` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `BT` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `BW` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `date` text COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `castomer` VALUES (20,"DA1C11","Monir","AhmadYar",20,"Male","Balkh","Teacher","Tab + romatism","Tab + romatism","Tab + romatism","12 mmhg","23  cycle/minute","23  bite/minute","23  cycle/minute","23  C","23  kg","۱۳۹۹/۱/۲۰");


DROP TABLE IF EXISTS `customer_noskha`;

CREATE TABLE `customer_noskha` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `rx` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `naw` varchar(10) COLLATE utf8mb4_persian_ci NOT NULL,
  `time` varchar(10) COLLATE utf8mb4_persian_ci NOT NULL,
  `n` varchar(10) COLLATE utf8mb4_persian_ci NOT NULL,
  `ghiza` varchar(10) COLLATE utf8mb4_persian_ci NOT NULL,
  `date` text COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `customer_noskha` VALUES (72,"Monir","dawa","Tab","1 x 2",10,"wasat","۱۳۹۹/۱/۱۷"),
(73,"Monir","dawa","Tab","1 x 2",10,"wasat","۱۳۹۹/۱/۱۷"),
(74,"Monir","dawa","Tab","1 x 2",10,"wasat","۱۳۹۹/۱/۱۷"),
(75,"Monir","dd","Tab","1 x 2",22,"qabl","۱۳۹۹/۱/۱۷"),
(76,"Monir","parastamol","Tab","1 x 2","10p","qabl","۱۳۹۹/۱/۱۷"),
(77,"Monir","",""," x ","","wasat","۱۳۹۹/۱/۱۷"),
(78,"Monir","Ampol","Tab","1 x 2",10,"qabl","۱۳۹۹/۱/۱۷");


DROP TABLE IF EXISTS `drug_store`;

CREATE TABLE `drug_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `melegram` varchar(20) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `drug_store` VALUES (3,"dawa",20),
(6,"parastamol","20 gr"),
(7,"Ampol","30 mg"),
(8,"monir","30 mg"),
(9,"Ampol","20 mg"),
(10,"Ampol","10gr"),
(11,"new drug","10 gr");


DROP TABLE IF EXISTS `impression`;

CREATE TABLE `impression` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `impression` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `impression` VALUES (3,"Tab + romatism"),
(7,"lalalall ");


DROP TABLE IF EXISTS `licence`;

CREATE TABLE `licence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `licence` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `mac` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `licence` VALUES (1,121233,"F0-1F-AF-3A-FE-28","used"),
(2,22334,"","");


DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8mb4_persian_ci NOT NULL,
  `password` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `users` VALUES (1,"admin","walid"),
(2,"admin","monir123");


SET foreign_key_checks = 1;
