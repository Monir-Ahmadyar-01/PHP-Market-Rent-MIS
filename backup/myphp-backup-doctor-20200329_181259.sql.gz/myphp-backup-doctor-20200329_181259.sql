CREATE DATABASE IF NOT EXISTS `doctor`;

USE `doctor`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `castomer`;

CREATE TABLE `castomer` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `Patientid` varchar(50) COLLATE utf8mb4_persian_ci NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_persian_ci NOT NULL,
  `surname` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `age` int(5) NOT NULL,
  `gender` varchar(10) COLLATE utf8mb4_persian_ci NOT NULL,
  `Province` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `Job` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `Diagnosis1` varchar(111) COLLATE utf8mb4_persian_ci NOT NULL,
  `Diagnosis2` varchar(111) COLLATE utf8mb4_persian_ci NOT NULL,
  `Diagnosis3` varchar(111) COLLATE utf8mb4_persian_ci NOT NULL,
  `BP` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `HR` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `PR` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `RR` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `BT` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `BW` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `date` text COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `castomer` VALUES (15,"5e7711d2bd6a2","kabir","karimzada",22,"Female","kandhar","teacher","Tab + romatism","Tab + romatism","Tab + romatism","12 mmhg","23  cycle/minute","23  bite/minute","23  cycle/minute","22 C","23  kg","۱۳۹۹/۱/۴"),
(16,"5e7c5f64a9df6","Ahmad Jawid","karimi",22,"Male","Balkh","Teacher","Tab + romatism","Tab + romatism","Tab + romatism","12 mmhg","23  cycle/minute","23  bite/minute","23  cycle/minute","23  C","23  kg","۱۳۹۹/۱/۷"),
(17,"5e7c602ec5387","کبیر","AhmadAYar",31,"Male","kandhar","teacher","Tab + romatism","Tab + romatism","Tab + romatism","12 mmhg","23  cycle/minute","23  bite/minute","23  cycle/minute","23  C","23  kg","۱۳۹۹/۱/۷");


DROP TABLE IF EXISTS `customer_noskha`;

CREATE TABLE `customer_noskha` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `rx` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `date` text COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `customer_noskha` VALUES (20,"ali","dawa\t\t20","۱۳۹۸/۱۲/۱۷"),
(21,"ali","parastamol     15mg","۱۳۹۸/۱۲/۱۷"),
(22,"ali","dawa\t\t20","۱۳۹۸/۱۲/۱۷"),
(23,"kabir","","۱۳۹۹/۱/۴"),
(24,"kabir","","۱۳۹۹/۱/۴"),
(25,"kabir","","۱۳۹۹/۱/۴"),
(26,"kabir","","۱۳۹۹/۱/۴"),
(27,"kabir","dawa\t\t20","۱۳۹۹/۱/۴");


DROP TABLE IF EXISTS `drug_store`;

CREATE TABLE `drug_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `melegram` varchar(20) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `drug_store` VALUES (3,"dawa",20),
(6,"parastamol","20 gr"),
(7,"Ampol","30 mg"),
(8,"monir","30 mg");


DROP TABLE IF EXISTS `impression`;

CREATE TABLE `impression` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `impression` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `impression` VALUES (3,"Tab + romatism"),
(7,"lalalall ");


DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8mb4_persian_ci NOT NULL,
  `password` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `users` VALUES (1,"admin","walid"),
(2,"admin","monir123");


SET foreign_key_checks = 1;
